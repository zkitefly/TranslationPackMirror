---
navigation:
  title: 介绍
  icon: "minecraft:redstone"
  position: 0
---

# Just Dyna Things

Just Dire Things的附属，加了新东西。

<SubPages />
