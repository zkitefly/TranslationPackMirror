---
navigation:
  title: 回响相能母岩
  icon: "justdynathings:echoing_budding_phasorite"
  position: 5
  parent: justdynathings:buddings.md
item_ids:
  - justdynathings:echoing_budding_phasorite
---

# 回响相能母岩

消耗Forge能量（Forge Energy）和时间流体来生长晶簇的相能母岩。

<BlockImage id="justdynathings:echoing_budding_phasorite" p:alive="false" scale="4.0"/>

<BlockImage id="justdynathings:echoing_budding_phasorite" p:alive="true" scale="4.0"/>

<RecipeFor id="justdynathings:echoing_budding_phasorite" />
