---
navigation:
  title: 焊枪
  icon: "synergy:soldering_gun"
  parent: tools.md
  position: 7
categories:
  - tools
item_ids:
  - synergy:soldering_gun
---

# 焊枪

用于扩展/缩减部分机器工作范围的尺寸。

<ItemImage id="synergy:soldering_gun" scale="4.0"/>

<RecipeFor id="synergy:soldering_gun" />
