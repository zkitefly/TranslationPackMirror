---
navigation:
  title: 循环中继器
  icon: "synergy:recursive_repeater"
  parent: redstone.md
  position: 2
categories:
  - redstone
item_ids:
  - synergy:recursive_repeater
---

# 循环中继器

全新的红石元件，激活时可按照设定的延时重复产生信号。

<ItemImage id="synergy:recursive_repeater" scale="4.0"/>

<RecipeFor id="synergy:recursive_repeater" />
