---
navigation:
  title: 激光透镜
  icon: "synergy:laser_lens"
  parent: lasers.md
  position: 2
categories:
  - lasers
item_ids:
  - synergy:laser_lens
---

# 激光透镜

中继任意激光轨迹。

<BlockImage id="synergy:laser_lens" scale="4.0"/>

<RecipeFor id="synergy:laser_lens" />
