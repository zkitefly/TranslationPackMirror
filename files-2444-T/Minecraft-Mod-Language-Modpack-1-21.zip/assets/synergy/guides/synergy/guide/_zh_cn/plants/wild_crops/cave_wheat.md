---
navigation:
  title: 野生洞穴小麦
  icon: "synergy:wild_cave_wheat"
  parent: plants.md
  position: 11
categories:
  - wild_crops
item_ids:
  - synergy:wild_cave_wheat
---

# 野生洞穴小麦

生成于主世界的灌木，会掉落<ItemLink id="synergy:cave_wheat_seed"/>。

<BlockImage id="synergy:wild_cave_wheat" scale="4.0"/>

### 植物属性

| 右击收获                          | 可用骨粉催熟                      | 会扩散                            | 光照等级                           | 生成位置       |
| --------------------------------- | --------------------------------- | --------------------------------- | ---------------------------------- | -------------- |
| <Color color="#ff0000">否</Color> | <Color color="#ff0000">否</Color> | <Color color="#ff0000">否</Color> | <Color color="#ffff00">NaN</Color> | 主世界（地下） |
|                                   |                                   |                                   |                                    |                |
