---
navigation:
  title: 红石电路
  icon: "synergy:pulse_repeater"
  position: 2
categories:
  - main
---

# 红石电路

全新的红石元件，用于简化过于复杂的设施。

<CategoryIndex category="redstone"></CategoryIndex>
