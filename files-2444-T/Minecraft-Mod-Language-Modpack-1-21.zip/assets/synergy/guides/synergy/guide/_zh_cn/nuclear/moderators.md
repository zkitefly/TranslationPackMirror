---
navigation:
  title: 慢化器
  icon: "synergy:elite_moderator"
  parent: nuclear.md
  position: 3
categories:
  - nuclear
item_ids:
  - synergy:simple_moderator
  - synergy:advanced_moderator
  - synergy:elite_moderator
---

# 慢化器

量子反应堆的组成部分。用于增加燃料单元的生产效率。