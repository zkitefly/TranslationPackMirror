---
navigation:
  title: 电池
  icon: "synergy:blue_battery"
  parent: tools.md
  position: 7
categories:
  - tools
item_ids:
  - synergy:green_battery
  - synergy:blue_battery
  - synergy:red_battery
---

# 电池

用于手动搬运FE和向方块注入FE的特殊物品。

<ItemImage id="synergy:green_battery" scale="4.0"/>
<ItemImage id="synergy:blue_battery" scale="4.0"/>
<ItemImage id="synergy:red_battery" scale="4.0"/>

<RecipeFor id="synergy:green_battery" />
<RecipeFor id="synergy:blue_battery" />
<RecipeFor id="synergy:red_battery" />