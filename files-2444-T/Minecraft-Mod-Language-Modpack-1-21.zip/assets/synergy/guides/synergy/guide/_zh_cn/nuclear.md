---
navigation:
  title: 核电科技
  icon: "synergy:quantum_reactor_controller"
  position: 6
categories:
  - main
---

# 核电科技

极其昂贵但也极其强大的方块，能够加工资源和产生能量。

_灵感来源于核电工艺（NuclearCraft）_

<CategoryIndex category="nuclear"></CategoryIndex>
