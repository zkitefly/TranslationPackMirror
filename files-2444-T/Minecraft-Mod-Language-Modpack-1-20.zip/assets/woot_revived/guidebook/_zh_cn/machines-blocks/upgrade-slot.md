---
navigation:
    parent: machines-blocks/machines-blocks-index.md
    title: "升级插槽"
    icon: "woot_revived:factory_upgrade"
---
# 升级插槽

<BlockImage id="factory_upgrade" scale="5" p:attached="true" />

<ItemImage id="factory_upgrade" scale="0.5"/>升级插槽能够存放工厂的升级物品

可使用任意升级对其右击来将升级安装到该方块上

可在[此处](../upgrades/upgrades-index.md)查看升级列表

## 合成

前往[此处](../upgrades/upgrade-base.md)来了解如何合成升级插槽

<RecipeFor id="factory_upgrade" />