---
navigation:
    parent: upgrades/upgrades-index.md
    title: "斩首升级"
    icon: "woot_revived:netherite_decapitate_upgrade"
    position: 1
---
# 斩首升级

<Row>
  <ItemImage id="copper_decapitate_upgrade" scale="3"/>
  <ItemImage id="iron_decapitate_upgrade" scale="3"/>
  <ItemImage id="gold_decapitate_upgrade" scale="3"/>
  <ItemImage id="diamond_decapitate_upgrade" scale="3"/>
  <ItemImage id="netherite_decapitate_upgrade" scale="3"/>
</Row>

斩首升级能够模拟闪电苦力怕爆炸，将掉落的头颅添加至战利品输出中。

## 斩首升级 I

掉落一个头颅

<RecipeFor id="copper_decapitate_upgrade" />

## 斩首升级 II

掉落两个头颅

<RecipeFor id="iron_decapitate_upgrade" />

## 斩首升级 III

掉落三个头颅

<RecipeFor id="gold_decapitate_upgrade" />

## 斩首升级 IV

掉落四个头颅

<RecipeFor id="diamond_decapitate_upgrade" />

## 斩首升级 V

掉落五个头颅

<RecipeFor id="netherite_decapitate_upgrade" />