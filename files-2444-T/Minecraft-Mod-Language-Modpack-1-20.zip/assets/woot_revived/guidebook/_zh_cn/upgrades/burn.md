---
navigation:
    parent: upgrades/upgrades-index.md
    title: "燃烧升级"
    icon: "woot_revived:burn_upgrade"
    position: 1
---
# 燃烧升级

<ItemImage id="burn_upgrade" scale="3"/>

<ItemImage id="burn_upgrade" scale="0.5"/>燃烧升级会在模拟生物击杀时施加点燃效果。

## 合成

<RecipeFor id="burn_upgrade" />