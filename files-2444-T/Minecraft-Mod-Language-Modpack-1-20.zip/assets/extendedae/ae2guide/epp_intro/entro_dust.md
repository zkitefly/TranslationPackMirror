---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Entro Dust
    icon: extendedae:entro_dust
categories:
- entro system
item_ids:
- extendedae:entro_dust
---

# Entro Dust

<Row>
<ItemImage id="extendedae:entro_dust" scale="4"></ItemImage>
</Row>

You can get it by crushing a <ItemLink id="extendedae:entro_crystal" /> or breaking [Entroized Fluix Budding](./entro_budding.md).

It is used to craft certain ExtendedAE machines and <ItemLink id="extendedae:entro_ingot" />.
