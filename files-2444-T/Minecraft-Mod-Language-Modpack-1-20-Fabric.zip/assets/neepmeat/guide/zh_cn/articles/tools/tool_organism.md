---
id: tool_organism
lookup: neepmeat:living_tool_implant
---
# 工具生物体

工具生物体会为工具提供自我修复功能。

可使用PLC的COMBINE操作将其嵌装至工具。