---
id: verrucous_rocks
lookup: neepmeat:verrucous_stone, neepmeat:verrucous_stone_port
---
# 疣斑石

随着环境中启智微型活体的浓度不断上升，岩石常有可能因此获得生物特性，生长成疣状的结构。

# 使用方法

疣斑石产出的腺体分泌物基本等效于瞬变浆液，也同样能用来驱动机器。这种流体会从岩石表面的溃疡处渗出，可由管道运输，以作常态能量源。单处岩体上可能出现多个溃疡口。

每块疣斑石都能产出10eJ/t。各溃疡口均分产出。