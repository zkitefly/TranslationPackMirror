---
id: mining_tools
lookup: neepmeat:drill_chassis, neepmeat:iron_rotary_drill_head, neepmeat:meat_steel_rotary_drill_head, neepmeat:diamond_rotary_drill)head, neepmeat:rock_drill_head
---
# 挖掘工具

NEEPMeat的工具与矿石处理系统与原版Minecraft有所不同。两者的主要区别在于，前者的矿石处理流水线直接使用矿石方块，而非粗矿。

使用配备旋转式钻头的钻具底盘挖掘铁矿石、金矿石等矿石会掉落矿石方块。

## 钻具底盘

钻具底盘是一种模块化挖掘工具。默认情况下，它自带气动发动机，且其运作需消耗压缩空气。这也意味着，此工具只能在距便携式压缩机25格内的位置使用。便携式压缩机有两种款式：

- 压缩机矿车
- 压缩机爬虫 - 会跟随放置它的玩家

钻头的核心植入物可在PLC辅助下替换为工具生物体。该植入物可让钻头使用液态可食用资源运作，如动物饲料、液态食物等。

钻具底盘也兼容肉质武器模块。可在改装台处替换头部和模块。

## 钻头

- 往复式钻头 - 能瞬间挖掘石头类方块
- 旋转式钻头 - 与镐类似，但矿石方块会**原样掉落，而非掉落粗矿**