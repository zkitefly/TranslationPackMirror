---
id: trommel
---

# 滚筒筛

其他的滚筒筛能从水中分离掉岩屑，这台滚筒筛同样能去除肉和脂肪中的杂质。平凡的污染物会留在筛网中，而提纯后的产物则会流出筛外。

与直接压榨污浊矿石脂肪相比，使用滚筒筛处理可将产量提高至150%。 

使用大型绞碎机或处死用扇刃分解生物体后，所产出的组织浆液可在此提纯为精制肉，且有概率产出生物固态物糊。

# 规格说明

\columns{\graph{neepmeat:small_trommel}}{最小功率：20eJ/t
最大功率：500eJ/t
}

# 使用方法

流体需从近端方块上部的容器送入，产物会从远端方块下部输出。

\image[width=299,height=178]{neepmeat:guide/images/trommel.png}

需要接上旋转中的发动机才可运作。

\image[width=322,height=237]{neepmeat:guide/images/trommel_image.png}