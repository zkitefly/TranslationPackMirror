---
id: mixer
---

# 混合机

混合机是能混合流体和物品的两格高机器。需要旋转源才可运作。

# 规格说明

\columns{\graph{neepmeat:mixer}}{最小功率：40eJ/t
最大功率：800eJ/t}

## 使用方法

混合机会自动从与其下部相邻的储罐中取出流体。物品则必须通过漏斗或管道直接送入。

机器内物品和流体有对应配方时，混合加工即会启动。加工的速率由相连发动机的转速决定。

\image[width=128,height=128,scale=0.5]{neepmeat:guide/images/mixer.png}
