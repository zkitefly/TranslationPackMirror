<chapter name="item.goldGearItem.name"/>
<lore>
更复杂的工作需要大量非常小的互锁齿轮，而这种样式的铁质齿轮容易损坏。
黄金打造的微小齿轮永不损坏，因此它可以用于复杂的机械装置。
</lore>
<no_lore>
黄金齿轮是更高级别的齿轮，用于更大型的机器。
</no_lore>
<recipes_usages stack="buildcraftcore:gear_gold"/>
