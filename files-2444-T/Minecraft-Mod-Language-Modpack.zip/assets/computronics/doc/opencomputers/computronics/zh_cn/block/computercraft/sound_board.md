# 外置声卡

![空间不足。](block:computronics:sound_board)

此方块与[声卡](../../item/sound_card.md)等效，但适用于ComputerCraft模组。
