# 指示灯面板

![Notch说，要有光。](item:computronics:oc_parts@10)

此面板可安装于机架中。它为用户提供了四个视觉指示灯，与其相连接的电脑可通过其提供的`light_board`组件对指示灯进行控制。

使用任意种类的[扳手](/%LANGUAGE%/item/wrench.md)与此面板交互即可改变其布局。请注意改变布局时其颜色设定会重置。
