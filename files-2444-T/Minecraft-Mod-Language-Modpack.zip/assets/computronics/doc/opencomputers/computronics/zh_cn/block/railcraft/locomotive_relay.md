# 数字化机车中继器

![欢迎来到未来。](block:computronics:locomotive_relay)

数字化机车中继器可令电脑与Railcraft模组的电力机车交互。你需要用到[数字化中继器传感器](../../item/railcraft/relay_sensor.md)来进行配对：潜行右键单击以将[中继器传感器](../../item/railcraft/relay_sensor.md)绑定到机车中继器，然后潜行左键单击一台电力机车以将[传感器](../../item/railcraft/relay_sensor.md)附到机车上。连接后，电力机车可通过`locomotive_relay`组件API进行控制。
