# 无人机停靠升级

![上半部分。](item:computronics:docking_upgrade)

无人机停靠升级可令无人机停泊到附有[无人机停靠站](drone_station.md)的Buildcraft模组管道上。此升级可被安装进带有1级或更高级扩展槽位的无人机中。
