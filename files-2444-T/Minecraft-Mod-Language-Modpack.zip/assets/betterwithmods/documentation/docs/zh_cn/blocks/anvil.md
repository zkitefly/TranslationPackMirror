![融魂钢钢砧](block:betterwithmods:steel_anvil)

[融魂钢](../items/soulforged_steel.md)钢砧是工作台的升级版，拥有4x4的合成界面且支持合成3x3的合成配方，当你关闭界面的时候物品会依旧留在钢砧上