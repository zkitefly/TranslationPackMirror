RAM模块只定义了一个函数：
* `peek(int addr)`
  从RAM模块的`addr`地址（范围为0-255）读取一个值
  