---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: 扩展分子装配室
    icon: expatternprovider:ex_molecular_assembler
categories:
- extended devices
item_ids:
- expatternprovider:ex_molecular_assembler
---

# 扩展分子装配室

<Row gap="20">
<BlockImage id="expatternprovider:ex_molecular_assembler" scale="8"></BlockImage>
</Row>

扩展分子装配室是一种更高级的<ItemLink id="ae2:molecular_assembler" />。

它可以同时运行8个合成任务（你需要确保你的ME网络中存在<ItemLink id="ae2:crafting_accelerator" />），并且比普通的快两倍。

然而，它只支持来自<ItemLink id="ae2:pattern_provider" />的合成请求，所以不能直接向其中放入样板。

