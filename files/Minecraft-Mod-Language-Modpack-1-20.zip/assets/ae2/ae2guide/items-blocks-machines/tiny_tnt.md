---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 迷你TNT
  icon: tiny_tnt
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:tiny_tnt
---

# 迷你TNT

<BlockImage id="tiny_tnt" scale="8" />

专为小型爆炸设计的小型TNT。在制造<ItemLink id="quantum_entangled_singularity" />对的过程中非常有用。

如果需要在服务器中禁用TNT和苦力怕，可在配置文件中禁用此物品的地形破坏效果，从而允许在禁用破坏地形的情况下制作奇点对。

## 配方

<RecipeFor id="tiny_tnt" />
