---
navigation:
    title: AE2扩展介绍
    position: 60
---

# 扩展你的AE配置！

AE2扩展为现代AE带回了一些1.7.10/1.12.2时期的功能。

[前往GitHub！](https://github.com/GlodBlock/ExtendedAE) 

## 恩特罗水晶系统
<CategoryIndex category="entro system"></CategoryIndex>

## 扩展基础
<CategoryIndex category="extended foundation"></CategoryIndex>

## 扩展设备
<CategoryIndex category="extended devices"></CategoryIndex>

## 扩展物品
<CategoryIndex category="extended items"></CategoryIndex>
