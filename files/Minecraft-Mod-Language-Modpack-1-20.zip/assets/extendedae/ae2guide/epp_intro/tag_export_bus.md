---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: ME标签输出总线
    icon: extendedae:tag_export_bus
categories:
- extended devices
item_ids:
- extendedae:tag_export_bus
---

# ME标签输出总线

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_tag_export_bus.snbt"></ImportStructure>
</GameScene>

ME标签输出总线的性质与<ItemLink id="ae2:export_bus" />相同，但你可以通过物品/流体的标签进行过滤。

其它过滤规则与<ItemLink id="extendedae:tag_storage_bus" />相同。

