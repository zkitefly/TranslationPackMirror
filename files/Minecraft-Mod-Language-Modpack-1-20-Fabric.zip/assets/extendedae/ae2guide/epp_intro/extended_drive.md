---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: ME扩展驱动器
    icon: extendedae:ex_drive
categories:
- extended devices
item_ids:
- extendedae:ex_drive
---

# ME扩展驱动器

<Row gap="20">
<BlockImage id="extendedae:ex_drive" scale="8"></BlockImage>
</Row>

ME扩展驱动器是一种具有更多元件槽的<ItemLink id="ae2:drive" /> ，它可以容纳20个存储元件。