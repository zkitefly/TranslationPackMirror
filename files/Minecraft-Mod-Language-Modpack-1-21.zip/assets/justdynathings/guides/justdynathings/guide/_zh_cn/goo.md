---
navigation:
  title: 新凝胶
  icon: "justdirethings:gooblock_tier1"
  position : 3
---

# 凝胶

全新等级的凝胶！

<CategoryIndex category="goo"></CategoryIndex>


*给各级凝胶都加个用法类似<ItemLink id="justdynathings:energized_goo"/>的变种大概也很不错，所以我还加了下面的凝胶！⸺DevDyna*

<CategoryIndex category="energy_goo"></CategoryIndex>
