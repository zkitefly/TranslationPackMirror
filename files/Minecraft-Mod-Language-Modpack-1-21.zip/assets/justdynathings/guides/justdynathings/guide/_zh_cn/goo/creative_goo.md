---
navigation:
  title: 创造凝胶
  icon: "justdynathings:creative_goo"
  parent: goo.md
  position : 99
categories:
- goo
item_ids:
  - justdynathings:creative_goo
---

# 创造凝胶

不会失活的简单凝胶。


凝胶等级：**MAX**

<BlockImage id="justdynathings:creative_goo" scale="4.0" p:alive="false"/> 
<BlockImage id="justdynathings:creative_goo" scale="4.0" p:alive="true" />

可由任意扳手激活或失活。