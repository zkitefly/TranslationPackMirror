---
navigation:
  title: 介绍
  icon: "minecraft:redstone"
  position : 1
---

# Just Dyna Things

JustDireThings的附属，加了新东西。

<SubPages />