---
navigation:
  title: 烈焰金砧
  icon: "justdynathings:blazegold_anvil"
  position : 2
  parent: justdynathings:anvils.md
item_ids:
  - justdynathings:blazegold_anvil
---

# 烈焰金砧

使用熔岩和其他高温流体修复物品的砧。

<BlockImage id="justdynathings:blazegold_anvil" scale="4.0"/>

<RecipeFor id="justdynathings:blazegold_anvil" />