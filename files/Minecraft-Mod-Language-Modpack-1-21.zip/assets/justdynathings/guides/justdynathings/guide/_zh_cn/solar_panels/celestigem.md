---
navigation:
  title: 苍穹晶太阳能板
  icon: "justdynathings:celestigem_solar_panel"
  position : 3
  parent: justdynathings:solar_panels.md
item_ids:
  - justdynathings:celestigem_solar_panel
---

# 苍穹晶太阳能板

会生产Forge能量（Forge Energy）的太阳能板。

FE生产速率：**3840**

**条件：**
- 露天

**增益：**
- 邻近的太阳能板会增加产能速率

<BlockImage id="justdynathings:celestigem_solar_panel" scale="4.0"/>

<RecipeFor id="justdynathings:celestigem_solar_panel" />