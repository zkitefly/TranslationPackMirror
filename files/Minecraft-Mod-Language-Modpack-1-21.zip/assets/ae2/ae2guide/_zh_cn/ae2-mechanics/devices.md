---
navigation:
  parent: ae2-mechanics/ae2-mechanics-index.md
  title: 设备
  icon: interface
---

# 设备

“设备”一词指AE2网络中执行与网络自身相关功能的组件。它们基本都需要占用频道，[标准发信器](../items-blocks-machines/level_emitter.md)除外。

以下是一些例子：

*   <ItemLink id="interface" />
*   <ItemLink id="import_bus" />
*   <ItemLink id="storage_bus" />
*   <ItemLink id="pattern_provider" />
*   <ItemLink id="drive" />
