```json
{
  "title": "铁栏杆门",
  "icon": "supplementaries:iron_gate",
  "categories": [
    "minecraft:blocks",
    "minecraft:tag/fence_gates",
    "minecraft:group/building_blocks"
  ],
  "associated_items": [
    "supplementaries:iron_gate"
  ]
}
```

&spotlight(supplementaries:iron_gate)
**铁栏杆门**是一种装饰性方块，相当于[栅栏门](^minecraft:tag/fence_gates)的升级版。

<block;supplementaries:iron_gate[open=false]>

;;;;;

&title(合成)
<recipe;supplementaries:iron_gate>

&title(连接)
铁栏杆门能在视觉上与其上方的栏杆门相连。
