```json
{
  "title": "金活板门",
  "icon": "supplementaries:gold_trapdoor",
  "categories": [
    "minecraft:blocks",
    "minecraft:tag/trapdoors",
    "minecraft:group/building_blocks",
    "minecraft:group/redstone_blocks"
  ],
  "associated_items": [
    "supplementaries:gold_trapdoor"
  ]
}
```

&spotlight(supplementaries:gold_trapdoor)
**金活板门**是使用金制造的[活板门](^minecraft:tag/trapdoors)，玩家无法与被红石充能的金活板门交互。


也即，被红石充能的金活板门无法打开也无法关闭，无论其当前是已打开还是已关闭。

;;;;;

&title(合成)
<recipe;supplementaries:gold_trapdoor>
