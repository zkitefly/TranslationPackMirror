```json
{
  "title": "门垫",
  "icon": "supplementaries:doormat",
  "categories": [
    "minecraft:blocks",
    "minecraft:group/functional_blocks"
  ],
  "associated_items": [
    "supplementaries:doormat"
  ]
}
```

&spotlight(supplementaries:doormat)
**门垫**能存储并显示3行文本。

<block;supplementaries:doormat>

;;;;;

![门垫](supplementaries:textures/gui/image/doormat.png,fit)

猫偶尔会坐在上面。

;;;;;

&title(合成)
<recipe;supplementaries:doormat_2>

;;;;;

&title(隐藏物品)
门垫下方可隐藏单个物品。Shift点击除顶面外的面可翻起门垫。
