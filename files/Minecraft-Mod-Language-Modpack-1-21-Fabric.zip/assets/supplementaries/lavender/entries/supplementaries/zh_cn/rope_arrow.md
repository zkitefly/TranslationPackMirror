```json
{
  "title": "绳索箭矢",
  "icon": "supplementaries:rope_arrow",
  "categories": [
    "minecraft:items",
    "minecraft:group/combat"
  ],
  "associated_items": [
    "supplementaries:rope_arrow"
  ]
}
```

&spotlight(supplementaries:rope_arrow)
**绳索箭矢**是箭的变种，会尝试在命中的位置放出一卷绳索。

;;;;;

&title(用途)
绳索箭矢可与绳索合成，以容纳最多24根绳索（可在配置中修改）。
发射出去的绳索会保留所有未放出的绳索，记得回收。


是洞穴探险的好帮手。
