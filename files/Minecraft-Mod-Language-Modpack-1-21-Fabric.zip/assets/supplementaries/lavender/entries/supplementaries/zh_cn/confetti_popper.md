```json
{
  "title": "彩花拉炮",
  "icon": "supplementaries:confetti_popper",
  "categories": [
    "minecraft:items",
    "minecraft:group/tools_and_utilities"
  ],
  "associated_items": [
    "supplementaries:confetti_popper"
  ]
}
```

&spotlight(supplementaries:confetti_popper)
**彩花拉炮**是能在使用（<keybind;key.use>）时放出彩花的工具。{red}好玩！{}

;;;;;

&title(合成)
<recipe;supplementaries:confetti_popper>


;;;;;

&title(用途)
可以戴在头上，当成派对帽。


苦力怕也能佩戴彩花拉炮！要小心它们爆炸就是了。
