```json
{
  "title": "切面地图",
  "icon": "supplementaries:slice_map",
  "categories": [
    "minecraft:items",
    "minecraft:group/tools_and_utilities"
  ],
  "associated_items": [
    "supplementaries:slice_map"
  ]
}
```

&spotlight(supplementaries:slice_map)
**切面地图**是能从特定Y坐标处标绘世界的物品。

;;;;;

&title(用途)
切面地图的Y坐标在第一次绘制时确定。需要玩家身处该高度，或有对应高度的视野，以避免透视。标绘范围小于普通的地图。


很适配Map Atlases模组。
