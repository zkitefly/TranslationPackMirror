```json
{
  "title": "竹笛",
  "icon": "supplementaries:flute",
  "categories": [
    "minecraft:items",
    "minecraft:group/tools_and_utilities"
  ],
  "associated_items": [
    "supplementaries:flute"
  ]
}
```

&spotlight(supplementaries:flute)
**竹笛**是能召唤附近不处于坐下状态宠物的乐器。

;;;;;

&title(合成)
<recipe;supplementaries:flute>


;;;;;

&title(绑定宠物)
竹笛可以与一只宠物（或一匹马）绑定，手持点击即可。经绑定的竹笛只能召唤所绑定的宠物。

;;;;;

&title(演奏音乐)
使用竹笛时，其会随机播放特定列表中的一首歌曲。将其重命名为已有歌曲的名称后，其将只会播放那一首歌曲。
