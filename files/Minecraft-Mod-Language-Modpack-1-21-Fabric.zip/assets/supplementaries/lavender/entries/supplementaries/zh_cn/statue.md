```json
{
  "title": "雕像",
  "icon": "supplementaries:statue",
  "categories": [
    "minecraft:blocks",
    "minecraft:group/functional_blocks"
  ],
  "associated_items": [
    "supplementaries:statue"
  ]
}
```

&spotlight(supplementaries:statue)
**雕像**的手中可容纳物品。


[蜡烛](^minecraft:candle)、[工具](^minecraft:tool)、剑等部分物品有特殊视觉效果。

;;;;;

&title(合成)
<recipe;supplementaries:statue>

;;;;;

&title(用途)
给予红石信号时会挥手。


Patreon赞助者和捐助者可以将雕像重命名为自己的名称，以让其变为拥有皮肤的特殊雕像。
