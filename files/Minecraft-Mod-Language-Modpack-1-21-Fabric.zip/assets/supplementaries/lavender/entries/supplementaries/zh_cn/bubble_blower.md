```json
{
  "title": "泡泡环",
  "icon": "supplementaries:bubble_blower",
  "categories": [
    "minecraft:items",
    "minecraft:group/tools_and_utilities"
  ],
  "associated_items": [
    "supplementaries:bubble_blower"
  ]
}
```

&spotlight(supplementaries:bubble_blower)
**泡泡环**是一件好玩的新奇物什，可以用它对朋友吹[肥皂](^supplementaries:soap)泡泡。{red}好玩！{}

;;;;;

&title(合成)
<recipe;supplementaries:bubble_blower>


;;;;;

&title(用途)
可以与[肥皂](^supplementaries:soap)合成补充肥皂量。


附魔有[稳定](^supplementaries:stasis)时，泡泡环便获得了一项有实际用途的功能：能够在空中所看处放置漂亮的[肥皂泡方块](^supplementaries:soap_block)。
