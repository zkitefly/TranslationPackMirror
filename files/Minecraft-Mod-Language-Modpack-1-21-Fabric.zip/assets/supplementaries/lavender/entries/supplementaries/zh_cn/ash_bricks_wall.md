```json
{
  "title": "灰烬砖墙",
  "icon": "supplementaries:ash_bricks_wall",
  "categories": [
    "minecraft:blocks",
    "minecraft:tag/walls",
    "minecraft:group/building_blocks"
  ],
  "associated_items": [
    "supplementaries:ash_bricks_wall"
  ]
}
```

&spotlight(supplementaries:ash_bricks_wall)
**灰烬砖墙**是[灰烬砖块](^supplementaries:ash_bricks)的[墙](^minecraft:tag/walls)变种。

;;;;;

&title(合成)
<recipe;supplementaries:ash_brick_wall>
<recipe;supplementaries:stonecutting/ash_brick_wall_from_bricks>
