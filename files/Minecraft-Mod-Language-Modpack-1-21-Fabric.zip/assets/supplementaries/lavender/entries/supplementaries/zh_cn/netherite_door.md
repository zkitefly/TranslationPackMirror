```json
{
  "title": "下界合金门",
  "icon": "supplementaries:netherite_door",
  "categories": [
    "minecraft:blocks",
    "minecraft:tag/doors",
    "minecraft:group/building_blocks",
    "minecraft:group/redstone_blocks"
  ],
  "associated_items": [
    "supplementaries:netherite_door"
  ]
}
```

&spotlight(supplementaries:netherite_door)
**下界合金门**是使用下界合金制造的[门](^minecraft:tag/doors)，与[保险箱](^supplementaries:safe)一样可以用[钥匙](^supplementaries:key)上锁。只有持有对应钥匙的人才能与上锁的下界合金门交互。


默认情况下，所有人都可与下界合金门交互，直至第一次上锁。

;;;;;

&title(合成)
<recipe;supplementaries:netherite_door>
