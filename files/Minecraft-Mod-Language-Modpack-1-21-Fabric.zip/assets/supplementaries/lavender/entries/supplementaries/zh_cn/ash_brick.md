```json
{
  "title": "灰烬砖",
  "icon": "supplementaries:ash_brick",
  "categories": [
    "minecraft:items",
    "minecraft:group/ingredients"
  ],
  "associated_items": [
    "supplementaries:ash_brick"
  ]
}
```

&spotlight(supplementaries:ash_brick)
**灰烬砖**是可投掷的物品。

;;;;;

&title(合成)
<recipe;supplementaries:ash_brick>

;;;;;

&title(合成材料)
<recipe;supplementaries:ash_bricks>
