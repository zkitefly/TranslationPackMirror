```json
{
  "title": "篝火",
  "icon": "supplementaries:fire_pit",
  "categories": [
    "minecraft:blocks",
    "minecraft:group/functional_blocks"
  ],
  "associated_items": [
    "supplementaries:fire_pit"
  ]
}
```

&spotlight(supplementaries:fire_pit)
**篝火**是装饰性物品，能作为火把的替代品。

<block;supplementaries:fire_pit>

;;;;;

&title(合成)
<recipe;supplementaries:fire_pit>

;;;;;

&title(用途)
可以用打火石、火焰弹、着火的箭、火药线点燃。


令篝火含水，或向篝火投掷喷溅型水瓶可以熄灭它。


不会被水冲毁。
