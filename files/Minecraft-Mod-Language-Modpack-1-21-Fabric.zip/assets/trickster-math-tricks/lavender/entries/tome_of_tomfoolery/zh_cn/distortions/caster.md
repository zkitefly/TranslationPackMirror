```json
{
  "title": "施法上下文",
  "icon": "trickster:wand",
  "category": "trickster-math-tricks:math-tricks"
}
```

本节中的错觉术能获取施法实体和方块的上下文。

;;;;;

<|glyph@trickster-math-tricks:templates|trick-id=trickster-math-tricks:caster_quaternion,title=旋向之错觉|>

-> quaternion

---

若可行，将施法实体头部的旋转方向返回为四元数。