```json
{
  "title": "侍者的誓言",
  "icon": "trickster:collar",
  "category": "trickster:items",
  "required_advancements": [
    "trickster:trigger/collar"
  ],
  "secret": true,
  "ordinal": 200
}
```

*我拿出了缚环：不过是由普通的染色皮革制成，但其上魔法无人不知⋯⋯*
⸺萨宁

<recipe;trickster:collar>

;;;;;

侍者的缚环和法师的捆索有一项特别的用途：允许某人以他人身份施法。

<recipe;trickster:leash>

一方佩戴未链接的缚环且保持潜行时，另一方对其使用捆索即可链接两者。

;;;;;

链接建立后，向捆索抄入法术再使用，即会以缚环佩戴者的身份进行施放。法术会占用佩戴者的法术槽，消耗佩戴者的魔力，且视作在佩戴者所处位置施放。不过，法术的第一参数会是使用捆索的实体。


*⋯⋯他欣然接受；他的自由相比法师的教诲而言，只是个微不足道的代价。*
⸺萨宁
