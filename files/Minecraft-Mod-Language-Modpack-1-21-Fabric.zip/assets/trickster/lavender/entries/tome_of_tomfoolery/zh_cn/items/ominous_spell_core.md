```json
{
  "title": "不祥法术核心",
  "icon": "trickster:ominous_spell_core",
  "category": "trickster:items",
  "required_advancements": [
    "trickster:ominous_spell_core"
  ],
  "secret": true,
  "ordinal": 130
}
```

[法术核心](^trickster:items/spell_core)的变种，出现在试炼密室的宝库中。它们执行法术的速度与玩家相当。其制作方法仍未解明，但它们与普通法术核心的区别只在于它们的那抹钻石光辉。
