```json
{
  "title": "介绍",
  "icon": "minecraft:written_book",
  "ordinal": 0
}
```

欢迎阅读《**魔术把戏秘典**》⸺你在魔法、魔术、应用数学领域中的指南！


本书分为数个分类下的许多章节。
除去“教程”分类外，其余章节并不要求按顺序阅读，也可只在有需求时才阅读。

;;;;;

如果在游玩模组时遇到了困难，或是很难理解某个概念和功能，抑或是碰见了漏洞或者其他问题，请在**[Discord](https://discord.gg/WcYsDDQtyR)**上告知我们。


以及在所有这些中最重要的，玩得开心！

![](trickster:textures/gui/img/catstare.png)
