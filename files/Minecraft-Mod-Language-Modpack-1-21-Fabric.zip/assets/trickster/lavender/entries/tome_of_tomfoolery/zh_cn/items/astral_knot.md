```json
{
  "title": "星辰晶结",
  "icon": "trickster:astral_knot",
  "category": "trickster:items",
  "required_advancements": [
    "trickster:astral_knot"
  ],
  "ordinal": 26
}
```

使用下界之星，可以制成星辰[晶结](^trickster:items/knots)。星辰晶结的容量在钻石晶结的几个数量级之上，但它有个怪癖：和紫水晶晶结一样，它不可由月光充能。相反，它自身为自身充能。

;;;;;

星辰晶结会根据其当前的存储量常态产生魔力。其中魔力越多，充能速度就越快。它在完全没有魔力的情况下便不会产生魔力。