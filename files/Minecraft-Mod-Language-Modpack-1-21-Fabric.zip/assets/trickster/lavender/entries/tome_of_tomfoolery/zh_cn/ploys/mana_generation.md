```json
{
  "title": "魔力生成",
  "icon": "minecraft:wheat_seeds",
  "category": "trickster:ploys",
  "additional_search_terms": [
    "栽培师之技巧"
  ]
}
```

此处的技巧术可以用来生成魔力。它们通常会返回产出后因存储容量不足而消散的魔力的量。

;;;;;

<|glyph@trickster:templates|trick-id=trickster:drain_matter,title=栽培师之技巧|>

vector -> number

---

可吸收给定位置处的柔软植物生物质，将其变为魔力。
