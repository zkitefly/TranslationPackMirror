```json
{
  "title": "教程",
  "icon": "minecraft:filled_map",
  "ordinal": 2
}
```

圆环魔术就此开始。
本分类下有若干按序排布的教程，以手把手教导最为重要的概念。
