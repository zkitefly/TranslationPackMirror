```json
{
  "title": "曲变术与谋略术",
  "icon": "trickster:scroll_and_quill",
  "ordinal": 2,
  "parent": "trickster:tricks"
}
```

曲变术是仅对数据进行操作的戏法。给定相同的输入，必定得出同样的输出。


谋略术是输入参数的数目可变的曲变术。
