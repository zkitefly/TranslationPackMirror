---
navigation:
  title: 带电雪球
  parent: items/index.md
  icon: powah:charged_snowball
  position: 2
item_ids:
  - powah:charged_snowball
---

# 带电雪球

落地或命中生物时会召唤闪电。充能雪球以获得。 

<Row>
<RecipesFor id="powah:charged_snowball" />
</Row>