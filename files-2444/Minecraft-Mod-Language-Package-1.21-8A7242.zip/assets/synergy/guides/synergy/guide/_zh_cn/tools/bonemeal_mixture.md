---
navigation:
  title: 骨粉混合物
  icon: "synergy:bone_meal_mixture"
  parent: tools.md
  position: 6
categories:
  - tools
item_ids:
  - synergy:bone_meal_mixture
---

# 骨粉混合物

强大的骨粉，有几项额外特性：

- 可根据所点击的花扩散植物

- 可加快任意植物的生长（如仙人掌）

<ItemImage id="synergy:bone_meal_mixture" scale="4.0"/>

<RecipeFor id="synergy:bone_meal_mixture" />
