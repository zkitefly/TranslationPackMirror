---
navigation:
  title: 发电机
  icon: powah:magmator_niotic
  position: 1
---

# 发电机

<SubPages />