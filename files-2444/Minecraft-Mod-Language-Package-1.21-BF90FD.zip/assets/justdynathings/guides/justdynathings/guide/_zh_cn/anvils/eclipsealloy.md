---
navigation:
  title: 蚀空合金砧
  icon: "justdynathings:eclipse_alloy_anvil"
  position: 4
  parent: justdynathings:anvils.md
item_ids:
  - justdynathings:eclipse_alloy_anvil
---

# 蚀空合金砧

和<ItemLink id="justdynathings:celestigem_anvil"/>一样使用Forge能量（Forge Energy，FE）修复物品的砧。引入[冷却剂](https://github.com/DevDyna/JustDynaThings/blob/main/src/generated/resources/data/justdynathings/data_maps/fluid/anvils/eclipsealloy_repair.json)后，此砧会根据`冷却剂效率 / 100 x 总耐久度`公式计算修复量；如果总耐久度小于1000，就可瞬间修复完毕。

<BlockImage id="justdynathings:eclipse_alloy_anvil" scale="4.0"/>

<RecipeFor id="justdynathings:eclipse_alloy_anvil" />

## 默认冷却剂

| 物品                                                                 | 效率  |
| -------------------------------------------------------------------- | ----- |
| <ItemLink id= "justdirethings:time_fluid_bucket"    scale="0.75" />  | 10.0x |
