---
navigation:
  title: 末影透镜
  parent: items/index.md
  icon: powah:lens_of_ender
  position: 6
item_ids:
  - powah:lens_of_ender
---

# 末影透镜

安装到太阳能板上时，可使其无视方块遮挡。 

<Row>
<RecipesFor id="powah:lens_of_ender" />
</Row>