---
navigation:
  title: 晶质铀矿矿石
  parent: materials/index.md
  icon: powah:uraninite_ore_dense
  position: 0
---

# 晶质铀矿矿石

![](./uraninite.png)

晶质铀矿矿石是一种稀有的矿石。其贫瘠变种生成于Y=64以下，普通变种生成于Y=20以下，致密变种生成于Y=0以下，以1-5个方块大小的矿团形式生成。 

需要铁镐及更高等级的镐来挖掘。挖掘时会根据矿石种类掉落1-4个粗晶质铀矿（受时运影响）。 
