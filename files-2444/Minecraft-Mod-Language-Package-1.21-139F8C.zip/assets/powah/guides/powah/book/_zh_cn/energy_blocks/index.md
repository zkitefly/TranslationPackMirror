---
navigation:
  title: 功能性方块
  icon: powah:player_transmitter_spirited
  position: 3
---

# 功能性方块

<SubPages />