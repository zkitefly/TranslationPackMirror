---
navigation:
  title: 核源铁太阳能板
  icon: "justdynathings:ferricore_solar_panel"
  position: 1
  parent: justdynathings:solar_panels.md
item_ids:
  - justdynathings:ferricore_solar_panel
---

# 核源铁太阳能板

会生产Forge能量（Forge Energy，FE）的太阳能板。

默认最大FE生产速率：**240**

**默认条件：**

- 维度为主世界
- 露天
- 日间

<BlockImage id="justdynathings:ferricore_solar_panel" scale="4.0"/>

<Recipe id="justdynathings:ferricore_solar_panel" />

*注意：所有东西都可以用配置修改，不要轻信！*
