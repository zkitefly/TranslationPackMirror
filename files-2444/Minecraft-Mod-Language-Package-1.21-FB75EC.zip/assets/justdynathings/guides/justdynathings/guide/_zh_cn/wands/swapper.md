---
navigation:
  title: 替换手杖
  icon: "justdynathings:swapper_wand"
  position : 1
  parent: justdynathings:wands.md
item_ids:
  - justdynathings:swapper_wand
---

# 替换手杖

可以替换方块的手杖，使用时不需破坏方块。

<ItemImage id="justdynathings:swapper_wand" scale="4.0"/>

<Recipe id="justdynathings:swapper_wand" />