---
navigation:
  title: 核源铁砧
  icon: "justdynathings:ferricore_anvil"
  position: 1
  parent: justdynathings:anvils.md
item_ids:
  - justdynathings:ferricore_anvil
---

# 核源铁砧

可以使用<ItemLink id="minecraft:iron_ingot"/>和<ItemLink id="justdirethings:ferricore_ingot"/>修复工具的砧。

<BlockImage id="justdynathings:ferricore_anvil" scale="4.0"/>

<RecipeFor id="justdynathings:ferricore_anvil" />

可修复的物品以及修复的耐久度均由[数据驱动](https://github.com/DevDyna/JustDynaThings/blob/main/src/generated/resources/data/justdynathings/data_maps/item/anvils/ferricore_repair.json)。