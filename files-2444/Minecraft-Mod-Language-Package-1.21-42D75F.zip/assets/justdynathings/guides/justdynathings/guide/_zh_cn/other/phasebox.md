---
navigation:
  title: 相变盒
  icon: "justdynathings:phase_box"
  position: 1
  parent: justdynathings:other.md
item_ids:
  - justdynathings:phase_box
---

# 相变盒

*又名缥缈玻璃*

可以在固态与非固态间切换的方块。

安装有**ConnectedTexturesMod**时还有连接纹理。

<BlockImage id="justdynathings:phase_box" scale="4.0"/>

<Recipe id="justdynathings:phase_box" />
