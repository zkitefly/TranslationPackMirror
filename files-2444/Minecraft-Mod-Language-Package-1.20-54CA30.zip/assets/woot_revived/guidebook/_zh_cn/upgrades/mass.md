---
navigation:
    parent: upgrades/upgrades-index.md
    title: "集群升级"
    icon: "woot_revived:iron_mass_upgrade"
    position: 1
---
# 集群升级

<Row>
  <ItemImage id="copper_mass_upgrade" scale="3"/>
  <ItemImage id="iron_mass_upgrade" scale="3"/>
  <ItemImage id="gold_mass_upgrade" scale="3"/>
  <ItemImage id="diamond_mass_upgrade" scale="3"/>
  <ItemImage id="netherite_mass_upgrade" scale="3"/>
</Row>

集群升级可令每次模拟击杀更多生物。

## 集群升级 I

击杀2个生物

<RecipeFor id="copper_mass_upgrade" />

## 集群升级 II

击杀4个生物

<RecipeFor id="iron_mass_upgrade" />

## 集群升级 III

击杀6个生物

<RecipeFor id="gold_mass_upgrade" />

## 集群升级 IV

击杀8个生物

<RecipeFor id="diamond_mass_upgrade" />

## 集群升级 V

击杀10个生物

<RecipeFor id="netherite_mass_upgrade" />
