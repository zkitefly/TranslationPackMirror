---
navigation:
  title: 回响紫水晶母岩
  icon: "justdynathings:echoing_budding_amethyst"
  position : 1
  parent: justdynathings:buddings.md
item_ids:
  - justdynathings:echoing_budding_amethyst
---

# 回响紫水晶母岩

消耗Forge能量（Forge Energy）和时间流体来生长晶簇的紫水晶母岩。

<BlockImage id="justdynathings:echoing_budding_amethyst" p:alive="false" scale="4.0"/>

<BlockImage id="justdynathings:echoing_budding_amethyst" p:alive="true" scale="4.0"/>


<RecipeFor id="justdynathings:echoing_budding_amethyst" />