<chapter name="item.paintbrush.name"/>
<lore>
在您惊叹于世界上发现的缤纷的涂抹和色彩的同时，不妨更进一步。想象一下只需简单一笔就能够改变某些方块的颜色。
虽然用于装饰性的涂抹方块很棒，但涂色也可以有实际用途，比如分隔管道。
</lore>
<no_lore>
颜料刷可用于将各种不同的方块涂成16种颜色之一。
通常情况下，给方块涂色有装饰作用，但是一些方块一经涂色就会具有特殊属性。
例如，可以给管道涂色来相互隔离。
</no_lore>
<recipes_usages stack="buildcraftcore:paintbrush"/>