<chapter name="item.stoneGearItem.name"/>
<lore>
事实证明木头难以用来做正二八经的机器，因此你决定用石头制作一个新的齿轮。
它额外的优点是根本不会着火。
</lore>
<no_lore>
石质齿轮基本上是木质齿轮的升级版本，由于石头的硬度，可以用来制造更强大的机器。
</no_lore>
<recipes_usages stack="buildcraftcore:gear_stone"/>