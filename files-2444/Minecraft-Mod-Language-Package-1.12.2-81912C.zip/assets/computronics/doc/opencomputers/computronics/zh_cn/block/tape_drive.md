# 磁带机

![放磁带，别放胶带。](block:computronics:tape_reader)

磁带机是用于回放和录制音频数据的方块。[盒式磁带](../item/tape.md)可被装入磁带机中，且有容量从2到128分钟不等的多种型号。请注意，磁带机并不仅限于读写音频数据，其它类型的数据也可以被写入[盒式磁带](../item/tape.md)中。

鉴于文件尺寸较小，音频会被保存为DFPWM格式。要将MP3或其他常见音频格式转换为此格式很麻烦；但是，可以用[LionRay](http://wiki.vex.tty.sh/wiki:computronics:tape#lionray)程序将WAV文件转换成DFPWM格式。转换好的音频文件可以被逐字节写入盒式磁带中。可在[wiki](http://wiki.vex.tty.sh/dfpwm)中找到有关DFPWM的更详细信息。

磁带机还提供了一个`seek()`函数，此函数可以将[盒式磁带](../item/tape.md)快进到某个特定位置。向`seek()`函数传递负数值即可将[盒式磁带](../item/tape.md)倒带至先前的某个位置。

你可以创建一个名为`tape`的软盘，其中装有名称相同的程序。这样可实现更便利的读取、写入以及播放磁带功能。

若磁带机连接到了[音频线缆](audio_cable.md)，则它会将生成的音频信号通过线缆发送，而不是自身播放声音。
