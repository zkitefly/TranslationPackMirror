---
navigation:
  title: 绑定卡
  parent: items/index.md
  icon: powah:binding_card
  position: 4
item_ids:
  - powah:binding_card
---

# 绑定卡

绑定卡用于链接位于同一维度的玩家与玩家供电仪。 

用于玩家供电仪之前，需将其与自己绑定，右击以进行绑定。 

<Row>
<RecipesFor id="powah:binding_card" />
</Row>