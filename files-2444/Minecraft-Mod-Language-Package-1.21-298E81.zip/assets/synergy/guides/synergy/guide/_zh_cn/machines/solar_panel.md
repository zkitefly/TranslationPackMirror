---
navigation:
  title: 太阳能板
  icon: "synergy:solar_panel"
  parent: machines.md
  position: 3
categories:
  - machines
item_ids:
  - synergy:solar_panel
---

# 太阳能板

露天时能在日间产生FE的方块。

<BlockImage id="synergy:solar_panel" scale="4.0" p:north="false" p:south="false" p:east="false" p:west="false" p:enabled="true"/>

<RecipeFor id="synergy:solar_panel" />
