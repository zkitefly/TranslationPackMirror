---
navigation:
  title: 管道与节点
  icon: "synergy:pipe"
  position: 2
item_ids:
  - synergy:pipe
---

# 管道与节点

## 节点

使用特殊操作通过管道传输事物的功能方块。

<CategoryIndex category="pipes"></CategoryIndex>

## 管道

可连接到任意带有#synergy:can_connect标签的方块。本身也是安全的装饰材料。

<BlockImage id="synergy:pipe" scale="4.0"/>

<RecipeFor id="synergy:pipe" />
