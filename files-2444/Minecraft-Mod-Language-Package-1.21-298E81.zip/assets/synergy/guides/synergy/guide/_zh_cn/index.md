---
navigation:
  title: Synergy
  icon: "minecraft:redstone"
  position: 1
---

# Synergy - 一个魔法/科技模组

各种东西组成的模组，没有什么主题。

<SubPages />
