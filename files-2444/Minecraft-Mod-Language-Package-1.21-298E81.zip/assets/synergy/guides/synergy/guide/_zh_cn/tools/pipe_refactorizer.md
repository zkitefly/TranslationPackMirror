---
navigation:
  title: 管道重构器
  icon: "synergy:pipe_refactorizer"
  parent: tools.md
  position: 3
categories:
  - tools
item_ids:
  - synergy:pipe_refactorizer
---

# 管道重构器

更新某<ItemLink id="synergy:pipe" />/节点方块的各项状态。

很适合用于检修失效的管路和触发放置时被抑制的更新。

<ItemImage id="synergy:pipe_refactorizer" scale="4.0"/>

<RecipeFor id="synergy:pipe_refactorizer" />
