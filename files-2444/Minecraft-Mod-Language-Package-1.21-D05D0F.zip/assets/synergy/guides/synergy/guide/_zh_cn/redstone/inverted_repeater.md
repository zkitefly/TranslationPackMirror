---
navigation:
  title: 反相中继器
  icon: "synergy:inverted_repeater"
  parent: redstone.md
  position: 3
categories:
  - redstone
item_ids:
  - synergy:inverted_repeater
---

# 反相中继器

全新的红石元件，激活时可反转输入的（模拟）信号。

<ItemImage id="synergy:inverted_repeater" scale="4.0"/>

<RecipeFor id="synergy:inverted_repeater" />
