---
navigation:
  title: 脉冲中继器
  icon: "synergy:pulse_repeater"
  parent: redstone.md
  position: 1
categories:
  - redstone
item_ids:
  - synergy:pulse_repeater
---

# 脉冲中继器

全新的红石元件，激活时可将持续信号转变为脉冲。

<ItemImage id="synergy:pulse_repeater" scale="4.0"/>

<RecipeFor id="synergy:pulse_repeater" />
