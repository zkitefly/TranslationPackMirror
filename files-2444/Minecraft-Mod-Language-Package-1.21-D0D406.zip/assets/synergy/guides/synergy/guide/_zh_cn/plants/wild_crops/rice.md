---
navigation:
  title: 野生水稻
  icon: "synergy:wild_rice"
  parent: plants.md
  position: 13
categories:
  - wild_crops
item_ids:
  - synergy:wild_rice
---

# 野生水稻

生成于主世界的灌木，会掉落<ItemLink id="synergy:rice_seed"/>。

<BlockImage id="synergy:wild_rice" scale="4.0"/>

### 植物属性

| 右击收获                          | 可用骨粉催熟                      | 会扩散                            | 光照等级                           | 生成位置 |
| --------------------------------- | --------------------------------- | --------------------------------- | ---------------------------------- | -------- |
| <Color color="#ff0000">否</Color> | <Color color="#ff0000">否</Color> | <Color color="#ff0000">否</Color> | <Color color="#ffff00">NaN</Color> | 任意丛林 |
|                                   |                                   |                                   |                                    | 任意沼泽 |
|                                   |                                   |                                   |                                    | 任意沙滩 |
|                                   |                                   |                                   |                                    | 任意河流 |
