---
navigation:
  title: 激光
  icon: "synergy:laser_machine_gun"
  position: 5
categories:
  - main
---

# 激光

基于激光轨迹的功能方块。

<CategoryIndex category="lasers"></CategoryIndex>
