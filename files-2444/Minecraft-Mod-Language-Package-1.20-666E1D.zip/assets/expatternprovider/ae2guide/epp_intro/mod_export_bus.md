---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: ME模组输出总线
    icon: expatternprovider:mod_export_bus
categories:
- extended devices
item_ids:
- expatternprovider:mod_export_bus
---

# ME模组输出总线

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_mod_export_bus.snbt"></ImportStructure>
</GameScene>

ME模组输出总线的性质与<ItemLink id="ae2:export_bus" />相同，但你可以通过Mod名称进行过滤。

如果您想要过滤多个Mod，请使用逗号分隔多个Mod名称。

![PIC](../pic/mod_bus_name2.png)
