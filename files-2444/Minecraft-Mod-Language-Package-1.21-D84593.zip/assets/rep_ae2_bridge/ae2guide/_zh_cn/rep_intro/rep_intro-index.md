---
navigation:
    title: Replication联动
    icon: rep_ae2_bridge:rep_ae2_bridge
    position: 100
---

# Replication联动指南

欢迎阅读Replication与AE2联动内容的指南！此附属将应用能源2（Applied Energistics 2，AE2）与Replication的内容进行了关联，从而可在ME系统中直接取用物质。

## 目录

* [ME-Replication桥接器](repae2bridge.md)：连接两方体系的主要部件，同时有管理合成优先级的功能