![挚友方块](block:betterwithmods:companion_cube)

挚友方块通过把狼放在[方块放置回收器](block_dispenser.md)前面然后激活它即可，具体有啥用⋯⋯想一想你要如何在MC中还原出*DOG SONG* ;)

免责声明：只有少数数据化动物在此过程中受到了必要的伤害