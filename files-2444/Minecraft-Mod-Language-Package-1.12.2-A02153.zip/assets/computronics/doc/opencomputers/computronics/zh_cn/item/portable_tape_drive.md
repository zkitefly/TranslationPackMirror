# 便携式磁带驱动器

![音乐常伴你身边](item:computronics:portable_tape_drive@0)

便携式磁带驱动器是⋯⋯[磁带驱动器](../block/tape_drive.md)的便携版本！你可以在其中插入磁带，并在你离开家门的时候播放音乐。此设备适合在长时间挖矿工作中提供娱乐，或是与你的朋友分享音乐。

### 控制键位：

  * `Shift + Right Click:` 打开操作界面

  * `Right Click:` 切换播放或暂停状态

  * `Shift-Scrolling:` 快进或倒带
