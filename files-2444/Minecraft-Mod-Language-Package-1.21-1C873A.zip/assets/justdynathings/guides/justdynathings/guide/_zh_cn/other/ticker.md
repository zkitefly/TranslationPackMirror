---
navigation:
  title: 进刻器
  icon: "justdynathings:ticker"
  position: 8
  parent: justdynathings:other.md
item_ids:
  - justdynathings:ticker
---

# 时间是相对的

使用时间流体和能量加速高亮面方向上的方块（默认16倍）。

<BlockImage id="justdynathings:ticker" scale="4.0"/>

<Recipe id="justdynathings:ticker" />
