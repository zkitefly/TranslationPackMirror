---
navigation:
  title: 魔法奇观
  icon: "synergy:urn"
  position: 7
categories:
  - main
---

# 魔法奇观

不需要能量就能运作的功能方块。

<CategoryIndex category="magic"></CategoryIndex>
