---
navigation:
  title: 扳手
  parent: items/index.md
  icon: powah:wrench
  position: 1
item_ids:
  - powah:wrench
---

# 扳手

扳手有3种模式： 

配置模式：用于改变线缆的输入输出配置。 

链接模式：用于链接可链接方块，例如充能台与充能棒。 

旋转模式：用于水平旋转方块。 

<Row>
<RecipesFor id="powah:wrench" />
</Row>