---
navigation:
  title: 干冰
  parent: materials/index.md
  icon: powah:dry_ice
  position: 1
---

# 干冰

![](./dry_ice.png)

干冰主要用于降低反应堆的温度。它生成于Y=64以下，但同时也可以通过充能两个蓝冰获得。 
