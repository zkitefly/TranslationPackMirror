---
navigation:
  title: 短暂遗忘手杖
  icon: "justdynathings:temporal_stupefy_wand"
  position: 4
  parent: justdynathings:wands.md
item_ids:
  - justdynathings:temporal_stupefy_wand
---

# 短暂遗忘手杖

此手杖能够移除时间手杖实体，也能给予短暂的一忘皆空效果。

<ItemImage id="justdynathings:temporal_stupefy_wand" scale="4.0"/>

<Recipe id="justdynathings:temporal_stupefy_wand" />
