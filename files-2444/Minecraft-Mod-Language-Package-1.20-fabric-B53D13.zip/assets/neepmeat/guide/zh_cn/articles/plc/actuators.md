---
id: actuators
---
# 操作机构

- 植入器：唯一能对实体执行手术的操作机构。
- 机械臂：可高速执行大多数加工指令，但其范围有限。需外接发动机。
- 管道驱动器：允许PLC向物品管道网络发送请求。

\image[width=854,height=480,scale=0.6]{neepmeat:guide/images/plc_actuators.png}
\centering{左至右：植入器、机械臂、管道驱动器。}