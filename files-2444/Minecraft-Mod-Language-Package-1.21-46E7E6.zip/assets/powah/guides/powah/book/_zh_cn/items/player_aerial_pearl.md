---
navigation:
  title: 玩家天线珍珠
  parent: items/index.md
  icon: powah:player_aerial_pearl
  position: 3
item_ids:
  - powah:player_aerial_pearl
---

# 玩家天线珍珠

玩家天线珍珠用于合成玩家供电仪。 

对僵尸或尸壳使用天线珍珠获得。 

<Row>
<RecipesFor id="powah:player_aerial_pearl" />
</Row>