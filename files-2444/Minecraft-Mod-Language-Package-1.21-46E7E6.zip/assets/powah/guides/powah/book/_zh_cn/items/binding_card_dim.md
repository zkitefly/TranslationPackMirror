---
navigation:
  title: 绑定卡（跨维度）
  parent: items/index.md
  icon: powah:binding_card_dim
  position: 5
item_ids:
  - powah:binding_card_dim
---

# 绑定卡（跨维度）

绑定卡用于链接位于同一维度的玩家与玩家供电仪。 

用于玩家供电仪之前，需将其与自己绑定，右击以进行绑定。 

<Row>
<RecipesFor id="powah:binding_card_dim" />
</Row>