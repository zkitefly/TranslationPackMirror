---
navigation:
  title: 核源铁太阳能板
  icon: "justdynathings:ferricore_solar_panel"
  position : 1
  parent: justdynathings:solar_panels.md
item_ids:
  - justdynathings:ferricore_solar_panel
---

# 核源铁太阳能板

会生产Forge能量（Forge Energy）的太阳能板。

FE生产速率：**240**

**条件：**
- 维度为主世界
- 露天
- 日间

**增益：**
- 无

<BlockImage id="justdynathings:ferricore_solar_panel" scale="4.0"/>

<RecipeFor id="justdynathings:ferricore_solar_panel" />