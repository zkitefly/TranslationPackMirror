# item.diamondGearItem.name
<lore>
在你深入的采矿挖掘中，你发现了最稀有但也是最坚固的材料：钻石。
由于其强度，钻石齿轮能够完成最苛刻的任务，而不会损坏或磨损齿轮。
</lore>
<no_lore>
作为最终级别的齿轮，钻石齿轮是最坚固的齿轮，适用于最复杂的机器。
</no_lore>
<recipes_usages stack="buildcraftcore:gear_diamond"/>