<chapter name="item.wrenchItem.name"/>
<lore>
创造和使用机器非常有用，然而有时需要改变它们的操作方式和面朝方向。
扳手提供了解决方案：可以通过右击来修改机器或许多方块的状态。
</lore>
<no_lore>
扳手是用于旋转和操作方块、机器以及某些实体的基础工具。
</no_lore>
<recipes_usages stack="buildcraftcore:wrench"/>
