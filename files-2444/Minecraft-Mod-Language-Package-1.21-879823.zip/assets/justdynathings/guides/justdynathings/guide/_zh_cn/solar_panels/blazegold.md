---
navigation:
  title: 烈焰金太阳能板
  icon: "justdynathings:blazegold_solar_panel"
  position: 2
  parent: justdynathings:solar_panels.md
item_ids:
  - justdynathings:blazegold_solar_panel
---

# 烈焰金太阳能板

会生产Forge能量（Forge Energy，FE）的太阳能板。

最大FE生产速率：**960**

**条件：**
- 维度为下界

<BlockImage id="justdynathings:blazegold_solar_panel" scale="4.0"/>

<Recipe id="justdynathings:blazegold_solar_panel" />