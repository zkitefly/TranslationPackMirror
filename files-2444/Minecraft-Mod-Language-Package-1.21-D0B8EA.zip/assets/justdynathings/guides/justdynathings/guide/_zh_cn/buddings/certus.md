---
navigation:
  title: 回响赛特斯石英母岩
  icon: "justdynathings:echoing_budding_certus"
  position: 3
  parent: justdynathings:buddings.md
item_ids:
  - justdynathings:echoing_budding_certus
---

# 回响赛特斯石英母岩

消耗Forge能量（Forge Energy）和时间流体来生长晶簇的无瑕赛特斯石英母岩。

<BlockImage id="justdynathings:echoing_budding_certus" p:alive="false" scale="4.0"/>

<BlockImage id="justdynathings:echoing_budding_certus" p:alive="true" scale="4.0"/>

<RecipeFor id="justdynathings:echoing_budding_certus" />
