---
navigation:
  title: 机器
  icon: "minecraft:crafter"
  position: 5
---

# 机器

用于简化各种繁杂事项的功能性机器。

<CategoryIndex category="machines"></CategoryIndex>
