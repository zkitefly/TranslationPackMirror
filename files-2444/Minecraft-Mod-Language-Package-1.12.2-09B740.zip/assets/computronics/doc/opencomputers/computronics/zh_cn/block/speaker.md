# 扬声器

![已获Audiophile认证。](block:computronics:speaker)

这种电子原声音乐转换器可被连接到[音频线缆](audio_cable.md)上。此设备会接收通过线缆传输的任何音频信号，然后将其转换为声音，让其可被收听。
